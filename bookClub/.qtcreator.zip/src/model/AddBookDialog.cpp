// addbookdialog.cpp
#include "addbookdialog.h"
#include "ui_AddBookDialog.h" // این فایل توسط uic از addbookdialog.ui تولید می‌شود
#include <QFileDialog> // برای باز کردن پنجره انتخاب فایل
#include <QMessageBox> // برای نمایش پیغام‌های خطا یا موفقیت

AddBookDialog::AddBookDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddBookDialog)
{
    ui->setupUi(this);

    // اتصال سیگنال/اسلات برای دکمه‌ها (اگر در Designer وصل نشده باشند)
    connect(ui->selectCoverImageButton, &QPushButton::clicked, this, &AddBookDialog::on_selectCoverImageButton_clicked);
    connect(ui->selectBookPdfButton, &QPushButton::clicked, this, &AddBookDialog::on_selectBookPdfButton_clicked);
    connect(ui->addButton, &QPushButton::clicked, this, &AddBookDialog::on_addButton_clicked);
    connect(ui->cancelButton, &QPushButton::clicked, this, &AddBookDialog::on_cancelButton_clicked);

    // تنظیمات اولیه برای SpinBox ها
    ui->priceSpinBox->setSingleStep(1000.0);
    ui->priceSpinBox->setMinimum(0.0);
    ui->stockSpinBox->setMinimum(0);
    ui->discountSpinBox->setMinimum(0);
    ui->discountSpinBox->setMaximum(100);
}

AddBookDialog::~AddBookDialog()
{
    delete ui;
}

QString AddBookDialog::getBookTitle() const {
    return ui->titleLineEdit->text();
}

QString AddBookDialog::getBookAuthor() const {
    return ui->authorLineEdit->text();
}

QString AddBookDialog::getBookGenre() const {
    return ui->genreComboBox->currentText();
}

QString AddBookDialog::getBookDescription() const {
    return ui->descriptionTextEdit->toPlainText();
}

double AddBookDialog::getBookPrice() const {
    return ui->priceSpinBox->value();
}

int AddBookDialog::getBookStock() const {
    return ui->stockSpinBox->value();
}

double AddBookDialog::getBookDiscountPercentage() const {
    return ui->discountSpinBox->value();
}

QString AddBookDialog::getCoverImagePath() const {
    return m_coverImagePath;
}

QString AddBookDialog::getBookPdfPath() const {
    return m_bookPdfPath;
}

void AddBookDialog::on_selectCoverImageButton_clicked()
{
    QString filePath = QFileDialog::getOpenFileName(this,
                                                    tr("Select Cover Image"),
                                                    QDir::homePath(),
                                                    tr("Image Files (*.png *.jpg *.jpeg *.bmp)"));
    if (!filePath.isEmpty()) {
        m_coverImagePath = filePath;
        // نمایش پیش‌نمایش تصویر در QLabel
        QPixmap pixmap(filePath);
        if (!pixmap.isNull()) {
            ui->coverImageLabel->setPixmap(pixmap.scaled(ui->coverImageLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
            ui->coverImageLabel->setText(""); // پاک کردن متن اگر قبلاً متنی داشته
        } else {
            ui->coverImageLabel->setText(tr("Invalid Image!"));
        }
    }
}

void AddBookDialog::on_selectBookPdfButton_clicked()
{
    QString filePath = QFileDialog::getOpenFileName(this,
                                                    tr("Select Book PDF File"),
                                                    QDir::homePath(),
                                                    tr("PDF Files (*.pdf)"));
    if (!filePath.isEmpty()) {
        m_bookPdfPath = filePath;
        ui->bookPdfPathLineEdit->setText(QFileInfo(filePath).fileName()); // فقط نام فایل را نمایش دهد
    }
}

void AddBookDialog::on_addButton_clicked()
{
    // اعتبارسنجی ورودی‌ها
    if (getBookTitle().isEmpty() || getBookAuthor().isEmpty() || getBookGenre().isEmpty() ||
        getBookDescription().isEmpty() || m_coverImagePath.isEmpty() || m_bookPdfPath.isEmpty())
    {
        QMessageBox::warning(this, tr("Input Error"), tr("Please fill all required fields and select both cover image and PDF file."));
        return;
    }

    // اگر همه چیز درست بود، دیالوگ را با QDialog::Accepted ببند
    accept(); // این باعث می‌شود QDialog::exec() مقدار QDialog::Accepted را برگرداند
}

void AddBookDialog::on_cancelButton_clicked()
{
    // اگر کاربر لغو کرد، دیالوگ را با QDialog::Rejected ببند
    reject(); // این باعث می‌شود QDialog::exec() مقدار QDialog::Rejected را برگرداند
}
