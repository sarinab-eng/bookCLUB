// addbookdialog.h
#ifndef ADDBOOKDIALOG_H
#define ADDBOOKDIALOG_H

#include <QDialog>
#include <QLineEdit>
#include <QTextEdit>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include <QPushButton>
#include <QComboBox>
#include <QLabel>
#include <QMessageBox> // برای نمایش پیغام خطا یا موفقیت

namespace Ui {
class AddBookDialog;
}

class AddBookDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddBookDialog(QWidget *parent = nullptr);
    ~AddBookDialog();

    // متدهای عمومی برای دسترسی به اطلاعات وارد شده
    QString getBookTitle() const;
    QString getBookAuthor() const;
    QString getBookGenre() const;
    QString getBookDescription() const;
    double getBookPrice() const;
    int getBookStock() const;
    double getBookDiscountPercentage() const;
    QString getCoverImagePath() const;
    QString getBookPdfPath() const;

private slots:
    // اسلات برای انتخاب تصویر جلد
    void on_selectCoverImageButton_clicked();
    // اسلات برای انتخاب فایل PDF کتاب
    void on_selectBookPdfButton_clicked();
    // اسلات برای تایید و افزودن کتاب
    void on_addButton_clicked();
    // اسلات برای لغو عملیات
    void on_cancelButton_clicked();

private:
    Ui::AddBookDialog *ui;

    QString m_coverImagePath; // مسیر فایل تصویر جلد
    QString m_bookPdfPath;    // مسیر فایل PDF کتاب
};

#endif // ADDBOOKDIALOG_H
